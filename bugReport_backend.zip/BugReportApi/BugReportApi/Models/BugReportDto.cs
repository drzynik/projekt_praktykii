﻿namespace BugReportApi.Models
{
    public class BugReportDto
    {
        public string Description { get; set; }
        public string Email { get; set; }

    }
}
