﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BugReportApi.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }

}
