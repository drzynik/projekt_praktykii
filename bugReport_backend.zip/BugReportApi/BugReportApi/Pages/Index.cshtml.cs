using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BugReportApi.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
