const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

let gmClients = [];

app.get("/gm/stream", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  gmClients.push(res);

  req.on("close", () => {
    gmClients = gmClients.filter((c) => c !== res);
  });
});

// User wysyła wiadomosc
app.post("/message", (req, res) => {

  gmClients.forEach((client) => {
    client.write(`data: ${JSON.stringify({ ...req.body })}\n\n`);
  });

  res.send({ ok: true });
});

app.listen(3000, () => {
  console.log("Server on http://localhost:3000");
});
