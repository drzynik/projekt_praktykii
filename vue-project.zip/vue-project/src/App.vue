<script setup>
  import Gra from './components/gra.vue';
  import gameMaster from './components/gameMaster.vue';
  import stoły from './components/stoły.vue';
</script>

<template>
  <router-view />
</template>
